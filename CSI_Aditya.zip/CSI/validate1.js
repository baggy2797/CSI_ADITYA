function myfunction()
{


//Date
	var a = document.forms["csiform"]["date"];
	if(a.value == "")
	{
		alert("Please Enter the date in dd-mm-yyyy format");
	}
//Time
	var b = document.forms["csiform"]["time"];
	if(b.value == "")
	{
		alert("Please enter the time");
	}
//Speaker Name
	var x = document.forms["csiform"]["speaker"];
    	if (x.value == "")
    	{
        	alert("Speakers Name should not be blank !!");
        	return false;
    	}
	if (! allLetter(x))
	{
		 alert("FName should be all characters!!");
		 return false;
	}
//Hours
     	var h = document.forms["csiform"]["hours"];
    	if (h.value == "")
    	{
        	alert("Hours should not be blank !!");
    	}
//Contact number
	var y = document.forms["csiform"]["phone"];
	if (y.value == "")
	{
        	alert("Contact No. should not be blank !!");
		return false;
        }
	if (! allnumeric(y))
	{
		alert('Please input numeric characters only');
      		return false;
	}
//Email
	var z = document.forms["csiform"]["email"];
	if (z.value == "")
	{
        	alert("Email should not be blank !!");
		return false;
        }
	if (!ValidateEmail(z))
	{
		alert('Please input valid Email ID!!!');
      		return false;
	}
//day
	var d = document.forms["csiform"]["day"];
	if (!dayselect(d))
	{
		alert('Please input day!!!');
      		return false;
	}
//month
	var m = document.forms["csiform"]["month"];
	if (!monthselect(m))
	{
		alert('Please input month!!!');
      		return false;
	}
//Year
	var yr = document.forms["csiform"]["year"];
	if (!yr.value =="")
	{
		alert('Please input the date');
	}
//Department
	var t = document.forms["csiform"]["dept"];
	if (!deptselect(t))
	{
		alert('Please input valid Email ID!!!');
      		return false;
	}
//Class

}

		function allLetter(inputtxt)
                {
                 	var letters = /^[A-Za-z]+$/;
                 	if(inputtxt.value.match(letters))
                   	{
              	     		return true;
                   	}
                 	else
                   	{
              	     		return false;
                   	}
                }


            	function allnumeric(inputtxt)
               	{
                  	var numbers = /^[0-9]+$/;
                  	if(inputtxt.value.match(numbers))
                  	{
                    		return true;
                  	}
                  	else
                  	{
                    		return false;
                  	}
                }

  		function limit(element,limit)
              	{
                	var max_chars = limit;
			if(element.value.length > max_chars)
			{
                    		element.value = element.value.substr(0, max_chars);
                  	}
              	}

		function ValidateEmail(inputText)
		{
			var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
			if(inputText.value.match(mailformat))
			{
				alert("1");
				return true;
			}
			else
			{
				alert("2");
				return false;
			}
		}

		function deptselect(dept)
		{
			if(dept.value == "no")
			{
				alert('no');
				return false;
			}
			else
			{
				alert('yes');
				return true;
			}
		}

		function dayselect(day)
		{
			if(day.value <= 1 || day.value >= 31)
			{
				alert('no');
				return false;
			}
			else
			{
				alert('yes');
				return true;
			}
		}

		function monthselect(month)
		{
			if(month.value <=1 || month.value >=12)
			{
				alert('no');
				return false;
			}
			else
			{
				alert('yes');
				return true;
			}
		}
