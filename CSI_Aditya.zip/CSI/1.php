<?php


require('display.php');





if(isset($_POST['s1']))
{


	echo "check1";



$date=$_POST['date'];
$time=$_POST['time'];
$fname=$_POST['fname'];
$hours=$_POST['hours'];
$gender=$_POST['gender'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$day=$_POST['day'];
$month=$_POST['month'];
$dept=$_POST['dept'];
$class=$_POST['class'];
$message=$_POST['message'];

$write=mysqli_query($_connect,"INSERT INTO csidata (date1,time1,fname,hours,gender,phone,email,day,month,dept,class,message) VALUES ('$date','$time','$fname','$hours','$gender','$phone','$email','$day','$month','$dept','$class','$message')") or die("sql error");


  echo "Successful insertion";
}


 ?>









<!DOCTYPE html>
<html>
	<title>CSI</title>
<head>
	<link rel="stylesheet" type="text/css" href="1.css">

	<center>
		<link rel="icon" href="csi-logo.png" type="png">
		<img src="DBIT_logo1.png" alt="DBIT LOGO" style="width:200px;height:200px;">

		<font size="14" color="blue"><strong>Don Bosco Institute of Technology-CSI</strong>
		</font>

		<img src="csi-logo.png" alt="csi logo" style="width:200px;height:200px;">

	</center>
<hr>
</head>


<body bgcolor="#ecf0f1">
	<form name="form" action="1.php" method="POST" >
		<script type="javascript" src="first.js"></script>
		<ul id="m01">
  			<li id="m01"><a href="1.html">Home</a></li>
  			<li id="m01"><a href="#news">News</a></li>
  			<li id="m01"><a href="#contact">Contact</a></li>
  			<li id="m01"><a href="3.html">About</a></li>
  			<li id="m01"><a href="2.html">Speaker</a></li>
		</ul>
<hr>
	<center>
	<table>
	<tr>
		<td><h3>Registration for</h3></td>
		<td>:</td>
		<td><input type="text" name="course" placeholder="Workshop/demonstration" value="WORDPRESS"></td>
	</tr>
	</table>
	</center>
	<hr>

	<h1>Personal Information:</h1>
<center>
<fieldset>
<center>
<table>
	<tr>
		<td>DATE</td>
		<td>:</td>
		<td><input type="text" name="date" placeholder="dd/mm/yyyy"></td>
	</tr>

	<br>
	<br>

	<tr>
		<td>TIME</td>
		<td>:</td>
		<td><input type="text" name="time" placeholder="hrs:min:sec"></td>

	</center>

	<center>

	<tr>
		<td>SPEAKER</td>
		<td>:</td>
		<td><input type="text" name="fname" placeholder="Speaker Name"></td>
	</tr>

	<tr>
		<td>HOURS</td>
		<td>:</td>
		<td><input type="text" name="hours" placeholder="Hours"></td>
	</center>

	<center>

	<tr>
		<td>GENDER</td>
		<td>:</td>
  		<td><select name="gender">
  			<option value="true" selected>--Select Option--</option>
  			<option value="m" >Male</option>
  			<option value="f" >Female</option>
  			<option value="o">Other</option>
  			</select>
  		</td>
  	</tr>
  	</center>



 	<tr>
 		<td>CONTACT NUMBER</td>
 		<td>:</td>
 		<td><input type="text" name="phone" placeholder="Phone Number"></td>
 	</tr>

 	<tr>
 		<td>EMAIL</td>
 		<td>:</td>
 		<td><input type="text" name="email" placeholder="Email" ></td>
 	</tr>

 	<tr>
		<td>DATE OF BIRTH</td>
		<td>:</td>
		<td><select name="day">
  			<option value="true" selected>--Select Option--</option>
  			<option value="1" >1</option>
  			<option value="2" >2</option>
  			<option value="3">3</option>
  			<option value="4">4</option>
  			<option value="5">5</option>
  			<option value="6">6</option>
  			<option value="7">7</option>
  			<option value="8">8</option>
  			<option value="9">9</option>
  			<option value="10">10</option>
  			<option value="11">11</option>
  			<option value="12">12</option>
  			<option value="13">13</option>
  			<option value="14">14</option>
  			<option value="15">15</option>
  			<option value="16">16</option>
  			<option value="17">17</option>
  			<option value="18">18</option>
  			<option value="19">19</option>
  			<option value="20">20</option>
  			<option value="21">21</option>
  			<option value="22">22</option>
  			<option value="23">23</option>
  			<option value="24">24</option>
  			<option value="25">25</option>
  			<option value="26">26</option>
  			<option value="27">27</option>
  			<option value="28">28</option>
  			<option value="29">29</option>
  			<option value="30">30</option>
  			<option value="31">31</option>
 			</optgroup>
 		</select>
 		<select name="month">
  			<option value="true" selected>--Select Option--</option>
  			<option value="1" >January</option>
  			<option value="2" >February</option>
  			<option value="3">March</option>
  			<option value="4">April</option>
  			<option value="5">May</option>
  			<option value="6">June</option>
  			<option value="7">July</option>
  			<option value="8">August</option>
  			<option value="9">September</option>
  			<option value="10">October</option>
  			<option value="11">November</option>
  			<option value="12">December</option>
  			</optgroup>
  		</select>
  		<input type="number" name=""></td>

	</tr>
</table>
</center>
</fieldset>

<h1>Academic details:</h1>
<center>
	<fieldset>
	<table>
		<center>
	<tr>
		<td>DEPARTMENT</td>
		<td>:</td>
  		<td><select name="dept">
  			<option value="true" >--Select Option--</option>
  			<option value="it" >Information Technology</option>
  			<option value="comp">Computer Engineering</option>
  			<option value="extc">Electronic and Telecommunication</option>
  			<option value="mech">Mechanical Engineering</option>
		</select></td>
	</tr>
	</center>

	<tr>
  		<td>CLASS</td>
  		<td>:</td>
  		<td><select name="class">
  			<option value="true" >--Select Option--</option>
  			<option value="fe" >FE </option>
  			<option value="se" selected>SE</option>
  			<option value="te">TE</option>
  			<option value="be">BE</option>
 			</optgroup>
 		</select>
 		</td>
 	</tr>
 	</table>
	</fieldset>
</center>

	<h1>Other details:</h1>
<center>
<fieldset>
<center>
<table>
 	<tr>
 		<td>ABOUT YOURSELF</td>
 		<td>:</td>
 		<td><textarea name="message" rows="10" cols="30">
			</textarea></td>
	</tr>
	<tr>
		<td>TECHNICAL SKILLS</td>
		<td>:</td>
  		<td><input type="checkbox" name="member" value="C"> C<br>
  			<input type="checkbox" name="member" value="C++">C++<br>
  			<input type="checkbox" name="member" value="JAVA">JAVA<br>
  			<input type="checkbox" name="member" value="HTML">HTML<br>
  			<input type="checkbox" name="member" value="CSS">CSS<br>
  			<input type="checkbox" name="member" value="PHOTOSHOP">PHOTOSHOP</td>
  	</tr>
</table>
</center>
</fieldset>
</center>

	<h1>Confirmation:</h1>
<center>
<fieldset>
<center>
<table>
	<tr>
		<td>ARE YOU AN EXISTING Dbit-CSI MEMBER?</td>
		<td></td>
		<td><input type="radio" name="decision" value="y" checked>Yes
  			<input type="radio" name="decision" value="n" >No</td>
  	</tr>

  	<tr>
		<td>ARE YOU AN EXISTING CSI MEMBER?</td>
		<td></td>
		<td><input type="radio" name="decision" value="y" checked>Yes
  			<input type="radio" name="decision" value="n" >No</td>
  	</tr>

  	<tr>
  		<td>AMOUNT TO BE PAID:</td>
  		<td></td>
  		<td><input type="text" placeholder="Amount to be Paid" value="Rs.100"></td>
  	</tr>

  	<tr>
 		<td></td>
 		<td><input type="submit" name="s1" value="Submit" class="Submit"></td>
 		<td></td>
 	</tr>
</table>
</center>
</fieldset>
</center>

<hr>
	<p align="left">Developed & Designed By:<a href="https://www.adityabhagwatblog.wordpress.com">Aditya Bhagwat</a><p>
	<p align="right">For further details mail us at: csidbit@gmail.com</p>

		</form>
</body>
</html>
