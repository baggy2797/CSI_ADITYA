<?php



$_connect=mysqli_connect("localhost","root","","csiform") or die ("couldn't connect to server");
echo "connected";

?>
