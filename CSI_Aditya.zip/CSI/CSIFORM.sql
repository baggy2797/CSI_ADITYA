-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2017 at 05:09 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `csiform`
--

-- --------------------------------------------------------

--
-- Table structure for table `csidata`
--

CREATE TABLE IF NOT EXISTS `csidata` (
  `date1` text NOT NULL,
  `time1` text NOT NULL,
  `fname` varchar(25) NOT NULL,
  `hours` time NOT NULL,
  `gender` varchar(25) NOT NULL,
  `phone` bigint(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `day` int(25) NOT NULL,
  `month` varchar(25) NOT NULL,
  `dept` varchar(25) NOT NULL,
  `class` varchar(25) NOT NULL,
  `message` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `csidata`
--

INSERT INTO `csidata` (`date1`, `time1`, `fname`, `hours`, `gender`, `phone`, `email`, `day`, `month`, `dept`, `class`, `message`) VALUES
('02/08/2017', '03:25:25', '', '00:00:05', 'm', 3168468, 'adibhag@gmail.com', 4, '3', 'it', '', '	aaaaaaaaaaaaaaaaa		'),
('02/08/2017', '03:25:25', 'Aditya', '00:00:05', 'm', 3168468, 'adibhag@gmail.com', 1, '1', 'comp', 'se', 'asfdaffafaf			');
