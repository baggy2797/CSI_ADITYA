<?php

echo "<br>Happy Birthday<br>";

$servername="localhost";
$username="root";
$password="oracle";
$dbname="csiform";

$conn = new mysqli($servername, $username, $password,$dbname);

if ($conn->connect_error) 
{
    die ("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


?>
